# Quotes-App
<a href="https://github.com/minakadis"><img alt="views" title="Github views" src="https://komarev.com/ghpvc/?username=minakadis&style=flat-square" width="125"/></a>


Built with:
- HTML5 [Semantic Tags]
- CSS3 [Media Query]
- Bootstrap5 [Utilities, and Layout]
- JS [Objects, Array, DOM Selection, DOM Manipulation, Event Listener, and CSS Manipulation]

# Video:



[Quote-Of-The-Day.webm](https://github.com/MinaKadis/Quotes-App/assets/18472725/8712349f-2a9e-4526-b5e0-aad03a18bab1)

